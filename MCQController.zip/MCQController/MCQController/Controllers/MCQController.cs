﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace MCQController.Controllers
{
    public class MCQController : Controller
    {
        public IActionResult Index()
        {
            ViewData["name"] = "guest";
            HttpContext.Response.Cookies.Append("Q1", "0");
            HttpContext.Response.Cookies.Append("Q2", "0");
            HttpContext.Response.Cookies.Append("Q3", "0");


            return View();
        }
        public IActionResult Q1(string ans)
        {
           
                if (ans != null )
                {
                    if (ans == "No")
                        HttpContext.Response.Cookies.Append("Q2", "10");
                }
            
           
            return View();
        }
        public IActionResult Q2(string ans2)
        {
                if (ans2 != null )
                {
                    if (ans2 == "Cool")
                        HttpContext.Response.Cookies.Append("Q1", "10");
                }
                if (ans2 != null )
                {
                    if (ans2 == "No")
                        HttpContext.Response.Cookies.Append("Q3", "10");
                }
            
            return View();
        }
        public IActionResult Q3(string ans3)
        {

                if (ans3 != null)
                {
                    if (ans3 == "No")
                        HttpContext.Response.Cookies.Append("Q2", "10");
                }
     
            return View();
        }
        public IActionResult Result()
        {
           
            var ans1 = HttpContext.Request.Cookies["Q1"];
            var ans2= HttpContext.Request.Cookies["Q2"];
            var ans3 = HttpContext.Request.Cookies["Q3"];

            int result = 0;
            result += Convert.ToInt16(ans3);
            result += Convert.ToInt16(ans2);
            result += Convert.ToInt16(ans1);
            ViewData["res"] = result; 
            return View();
        }
    }
}
