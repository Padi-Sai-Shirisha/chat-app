﻿using System;
using System.Collections.Generic;
using System.Text;
/*
namespace Proj1Day17
{
    class program
    {
        static void Main()
        {
            Queue<string> generalQueue = new Queue<string>();
            Queue<string> snrcitizenQueue = new Queue<string>();
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("enter name and age of person");
                string name = Console.ReadLine();
                int age = int.Parse(Console.ReadLine());
                if (age >= 60)
                {
                    snrcitizenQueue.Enqueue(name);
                }
                else
                    generalQueue.Enqueue(name);


            }
            Console.WriteLine("start processing");
            while (snrcitizenQueue.Count > 0)
            {
                if (snrcitizenQueue.Count > 0)
                { Console.WriteLine(snrcitizenQueue.Dequeue()); }
                else if (generalQueue.Count > 0)
                {
                    Console.WriteLine(generalQueue.Dequeue());
                }


            }


        }
    }
}
*/
