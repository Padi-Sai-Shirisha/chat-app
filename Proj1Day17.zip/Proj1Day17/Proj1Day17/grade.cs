﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
/*
namespace Proj1Day17
{
    public class program
    {
        static void Main()
        {
            string[] questions =
            {
                "namespace has a collection interface",
               " a list in c# represent class list",
               "an array and any collection",
               "collection is a part of bcl"
            };
            BitArray actual = new BitArray(4);
            actual[0] = true;
            actual[1] = false;
            actual[2] = true;
            actual[3] = true;
            BitArray userAnswers = new BitArray(4);
            for (int i = 0; i < questions.Length; i++)
            {
                Console.WriteLine(questions[i]);
                Console.WriteLine("your ans");
                string userAnswerStr = Console.ReadLine().Trim().ToLower();
                if (userAnswerStr == "t")
                    userAnswers[i] = true;
                else if (userAnswerStr == "f")
                    userAnswers[i] = false;
                else
                {
                    Console.WriteLine("invalid");
                    i--;
                }
            }
            int score = Calculatescore(actual, userAnswers);
            Console.WriteLine("score:"+ score+"/4");
        }
        public static int Calculatescore(BitArray actual, BitArray userAnswers)
        {
            int score = 0;
            for (int i = 0; i < actual.Length; i++)
            {
                if (actual[i] == userAnswers[i]) score++;
            }
            return score;
        }
    }
}
*/
