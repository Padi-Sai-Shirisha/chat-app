﻿using System;
using System.Collections.Generic;
using System.Text;
/*
namespace Proj1Day17
{
    public class employee
    {
        public string name { get; set; }
        public string designation { get; set; }
    }
   public  class designatedlists
    {
        public List<employee> Pmlist { get; set; } = new List<employee>();
        public List<employee> PrjMlist { get; set; } = new List<employee>();
        public List<employee> TLlist { get; set; } = new List<employee>();
        public List<employee> Splist { get; set; } = new List<employee>();
        public List<employee> Jplist { get; set; } = new List<employee>();
    }
    public class program
    {
        public static void Main()
        {
            designatedlists d = new designatedlists();
            while (true)
            {
                Console.WriteLine("menu");
                Console.WriteLine("1.add employee");
                Console.WriteLine("2.display");
                Console.WriteLine("enter choice");
                int choice;
                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            employee e = new employee();
                            Console.WriteLine("enter name");
                            e.name = Console.ReadLine();
                            Console.WriteLine("designation");
                            e.designation = Console.ReadLine();
                            addtodesignationlist(d, e);
                            break;
                        case 2:
                            displaydesignationlist(d);
                            break;
                    }
                }
                else { Console.WriteLine("INVALID CHOICE"); }
            }
        }

        public static void addtodesignationlist(designatedlists d, employee e)
        {
            switch (e.designation)
            {
                case "PM":
                    d.Pmlist.Add(e);
                    break;
                case "PRJM":
                    d.PrjMlist.Add(e);
                    break;
                case "TL":
                    d.TLlist.Add(e);
                    break;
                case "SP":
                    d.Splist.Add(e);
                    break;
                case "JP":
                    d.Jplist.Add(e);
                    break;



            }
        }
        public static void displaydesignationlist(designatedlists d)
        {
            Console.WriteLine("program managers");
            displayemployees(d.Pmlist);
            Console.WriteLine("project managers");
            displayemployees(d.PrjMlist);
            Console.WriteLine("team leads");
            displayemployees(d.TLlist);
            Console.WriteLine("senior programmer");
            displayemployees(d.Splist);
            Console.WriteLine("junior programmer");
            displayemployees(d.Jplist);
        }
        public static void displayemployees(List<employee> employees)
        {
            foreach (var employee in employees)
            {
                Console.WriteLine(employee.name+" "+employee.designation);
            }
        }
    }
}

        
    
*/