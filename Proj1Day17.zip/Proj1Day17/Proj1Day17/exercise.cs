﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
/*
namespace Proj1Day17
{
   public class employee
    {
        public int id { get; set; }
            public string name { get; set; }    
        public int salary { get; set; }  
        public employee(int id, string name, int salary)
        {
            this.id = id;
            this.name = name;
            this.salary = salary;
        }   
    }
    public class program
    {
        public static void Main()
        {
            Hashtable employeeTable = new Hashtable();
            employeeTable.Add(101, new employee(101, "john", 55000));
            employeeTable.Add(102, new employee(102, "lol", 58000));
            employeeTable.Add(103, new employee(103, "kaun", 60000));
            employeeTable.Add(104, new employee(104, "ron", 55000));
            employeeTable.Add(105, new employee(105, "harry", 55000));
            Console.WriteLine("enter employee id to search");
            int searchid;
            if(int.TryParse(Console.ReadLine(), out searchid))
            {
                if(employeeTable.ContainsKey(searchid))
                {
                    employee foundemployee = (employee)employeeTable[searchid];
                    Console.WriteLine(foundemployee.name+"  "+foundemployee.id);  
                }
                else
                {
                    Console.WriteLine("employee not found");
                }
            }
            else
            { Console.WriteLine("INVALID INPUT"); }
        }
    }
    }
    
*/
    