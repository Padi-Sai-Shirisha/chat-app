﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
/*
namespace Proj1Day17
{
  public  class program
    {
        public static void Main(string[]args)
        {
            if(args.Length !=2) 
            {
                Console.WriteLine("usage:CopyFile<sourcePath><targetPath>");
                return;
            }
            string sourcePath = args[0];
            string targetPath = args[1]; 
            if(!File.Exists(sourcePath))
            {
                Console.WriteLine("source file doesnt exist");
                return;
            }
            try
            {
                File.Copy(sourcePath, targetPath, true);
                Console.WriteLine("copied");

            }
            catch (IOException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");  
            }

        }

    }
}
*/
public class employee
{
    public int id { get; set; }
    public string name { get; set; }
    public employee(int id, string name)
    {
        id = id;
        name = name;
    }
}
public class program
{
    public static void Main()
    {
        List<employee> employees = new List<employee>
        {
            new employee(1,"john"),
        new employee(2, "jack"),
        new employee(3, "jill"),
        new employee(4, "jolly"),
        new employee(5, "jin"),
        new employee(6, "jimmy"),
        new employee(7, "jordan"),
        new employee(8, "jo"),
        new employee(9, "joseph"),
        new employee(10, "jeevan"),
    };

        Console.Write("enter id");
        if (int.TryParse(Console.ReadLine(), out int inputId))
        {
            employee foundemployee = employees.Find(employee => employee.id == inputId);
            if (foundemployee != null)
            {
                string logmessage = "emp with id:{foundemployee.id}having name{foundemployee.name}has logged in at{DateTime.Now}";
                string logFilePAth = Path.Combine("Monica", "logindewtails.txt");
                try
                {
                    Directory.CreateDirectory("Monica");
                    using (StreamWriter writer = File.AppendText(logFilePAth))
                    {
                        writer.WriteLine(logmessage);
                    }
                    Console.WriteLine("logged in");
                }
                catch (Exception ex) { Console.WriteLine(ex.ToString()); }
            }
        }
    }
}


  