﻿using System;
using System.Collections.Generic;
using System.Text;
/*
namespace Proj1Day17
{
    public class program
    {
        public static void Main(string[] args)
        {
            Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();


                dictionary.Add("apple", new List<string> { "a fruit", "a company" });
            dictionary.Add("pple", new List<string> { "a fruit", "a company" });
            dictionary.Add("bat", new List<string> { "an animal", "to play" });
            dictionary.Add("lay", new List<string> { "lie down", "give egg" });
            dictionary.Add("lamb", new List<string> { "a fruit", "a company" });
            
            Console.WriteLine("enter a word to search");
            string searchword = Console.ReadLine();
            if (dictionary.ContainsKey(searchword))
            {
                List<string> meanings = dictionary[searchword];
                Console.WriteLine("meaning of searchword");
                for (int i = 0; i < meanings.Count; i++)
                {
                    Console.WriteLine(meanings[i]);
                }
            }
        }

    }
}


public class program
{
    public static void Main()
    {
        string fileName = "hello world.txt";
        while (true) 
        {
            Console.WriteLine("MENU");
            Console.WriteLine("1.WRITE A FILE");
            Console.WriteLine("2.APPEND A FILE");
            Console.WriteLine("3.READ A FILE");
            Console.WriteLine("4.EXIT");
            Console.WriteLine("ENTER CHOICE");
            int choice;
            if(int.TryParse(Console.ReadLine(), out choice))
            {
                switch(choice)
                {
                    case 1:Console.WriteLine("enter text");

                }
            }
        }
    }




using System;
using System.IO;
using System.Text;
namespace Prj1Day19Col
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fWrite = new FileStream(@"C:\Monica\Textfile.txt", FileMode.Append, FileAccess.Write, FileShare.None);
            var text = "This is some text written to the textfile " + "named Textfile using FileStream class.";
            // Store the text in a byte array with  UTF8 encoding (8-bit Unicode  Transformation Format) 
            byte[] writeArr = Encoding.UTF8.GetBytes(text);
            fWrite.Write(writeArr, 0, text.Length);   //Write to file
            fWrite.Close();
            FileStream fRead = new FileStream(@"C:\Monica\Textfile.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
            byte[] readArr = new byte[text.Length];
            int count;
            while ((count = fRead.Read(readArr, 0, readArr.Length)) > 0)
            {
                Console.WriteLine(Encoding.UTF8.GetString(readArr, 0, count));   //Read from file
            }
            fRead.Close();
        }
    }
}
*/