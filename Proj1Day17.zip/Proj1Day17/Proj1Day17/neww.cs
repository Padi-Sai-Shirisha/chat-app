﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/*
namespace Proj1Day17
{
    public class employee
    {
        public string name { get; set; }
        public int id { get; set; }    
    }
    public class program
    {
        static void Main()
        {
            List<employee> list1 = new List<employee>

            {
                new employee{id=1,name="aaka" },new employee{id=2,name="disha"},
            new employee{id=3,name="dip" }
            

            };
            List<employee> list2 = new List<employee>

            {
                new employee{id=4,name="cocoa" },new employee{id=1,name="aaka"},
            new employee{id=5,name="brownie" }
            };
            HashSet<employee> mergedemployees = new HashSet<employee>(list1.Concat(list2).ToList());
            
            foreach(var employee in mergedemployees)
            {
                Console.WriteLine(employee.id+"  "+employee.name);
                
            }
        }
    }
}
*/