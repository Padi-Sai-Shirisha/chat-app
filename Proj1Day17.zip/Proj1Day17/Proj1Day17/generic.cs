﻿using System;
using System.Collections.Generic;
using System.Text;
/*
namespace Proj1Day17
{
    public class findmaxmin<T> where T : IComparable<T>
    {
        public T findmax(params T[] elements)
        {
            if (elements.Length != 3)
                throw new ArgumentException();

            T max = elements[0];
            for (int i = 1; i < elements.Length; i++)
            {
                if (elements[i].CompareTo(max) > 0)
                    max = elements[i];
            }
            return max;
        }
        public T findmin(params T[] elements)
        {
            if (elements.Length != 3) throw new ArgumentException();
            T min = elements[0];
            for (int i = 1; i < elements.Length; i++)
            {
                if (elements[i].CompareTo(min) < 0)
                    min = elements[i];
            }
            return min;
        }
    }
        class program
        {
            public static void Main()
            {
                findmaxmin<double> doubleFinder = new findmaxmin<double>();
                double num1 = 10.5;
                double num2 = 4;
                double num3 = 2.5;
                double max=doubleFinder.findmax(num1,num2,num3);
                double min = doubleFinder.findmin(num1, num2, num3);
                Console.WriteLine("minimum="+min);
                Console.WriteLine("maximum="+max);

            }

        }

    }
*/
