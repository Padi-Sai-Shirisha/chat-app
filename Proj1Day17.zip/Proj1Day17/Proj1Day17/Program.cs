﻿using System;
using System.Collections;

/*
using System;

namespace Prj1Day17
{
    interface IHouse
    {
        void buildFloor();
        void buildCeiling();

    }
    class IglooHouse : IHouse
    {
        public void buildCeiling()
        {
            Console.WriteLine("Ceiling with IceDome");
        }

        public void buildFloor()
        {
            Console.WriteLine("Floor with IceBlocks");
        }
    }
    class TipiHouse : IHouse
    {
        public void buildCeiling()
        {
            Console.WriteLine("Ceiling with Wooden Carvings");
        }

        public void buildFloor()
        {
            Console.WriteLine("Floor with Wooden blocks");
        }
    }
    class BambooHouse : IHouse
    {
        public void buildCeiling()
        {
            Console.WriteLine("Ceiling with Bamboo strips");
        }

        public void buildFloor()
        {
            Console.WriteLine("Floor with bamboo blocks");
        }
    }

    class BuilderHouse
    {
        public IHouse GetHouse()
        {
            Console.WriteLine("Which house do you prefer: \n1. Bamboo");
            Console.WriteLine("2. Igloo\n3. Wooden\n Enter choice:");
            int ch = Convert.ToInt32(Console.ReadLine());
            if (ch == 1)
                return new BambooHouse();
            else if (ch == 2)
                return new IglooHouse();
            else
                return new TipiHouse();
        }
        public void buildHouse()
        {
            IHouse house = GetHouse();
            house.buildCeiling();
            house.buildFloor();
        }

    }
    internal class Program
    {
        static void Main(string[] args)
        {
            BuilderHouse builder = new BuilderHouse();
            builder.buildHouse();

        }
    }
}


*/
/*
namespace Prj1Day19Col
{

    class Program
    {
        static void Main(string[] args)
        {
            BitArray myBitArr1 = new BitArray(4);
            BitArray myBitArr2 = new BitArray(4);
            myBitArr1[0] = false;
            myBitArr1[1] = false;
            myBitArr1[2] = true;
            myBitArr1[3] = true;
            myBitArr2[0] = false;
            myBitArr2[2] = false;
            myBitArr2[1] = true;
            myBitArr2[3] = true;
            PrintValues("\n\nBA1 : ", myBitArr1);
            PrintValues("\n\nBA2 : ", myBitArr2);
            PrintValues("\n\nOr : BA1.Or(BA2) : ", myBitArr1.Or(myBitArr2));
        }
        public static void PrintValues(string s, IEnumerable myList)
        {
            Console.WriteLine(s);
            foreach (Object obj in myList)
            {
                Console.Write(obj + "\t");
            }
        }
    }
}



String s = “using System;
using System.Collections;
class BitArrayExample
{
    public static void Main()
    {
        BitArray myBitArr = new BitArray(5);
        myBitArr[0] = true;
        myBitArr[1] = true;
        myBitArr[2] = false;
        myBitArr[3] = true;
        myBitArr[4] = false;

        // To get the value of index at index 2
        Console.WriteLine(myBitArr.Get(2));

        // To get the value of index at index 3
        Console.WriteLine(myBitArr.Get(3));
    }
}”

Prepare 8 stack:
CBS:
{
CBE: }
SBS: [
SBE: ]
PS: (
PE: )
ABS: <
ABE : >


Push the elements from s accordingly.
Check the length of each pair: Like:
CBS.Length should be equal to CBE.Length

If the length are unequal, output:
	Compilation Error: Brackets mismatch
Else if length pairs match:
	Compiled successfully*
*/