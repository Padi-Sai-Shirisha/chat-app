﻿using Member.Data.Model;
using Member.Data.Interface;
using Member.Data.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Day35WebAPI.Controllers
{
    [Route("api/[controller]")]
    //[Produces("application/json")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private IMember members = new MembersRepository();
        [Microsoft.AspNetCore.Mvc.HttpGet]
        public ActionResult<IEnumerable<Members>> GetAllMembers()
        {
            return members.GetAllMember();
        }
        [Microsoft.AspNetCore.Mvc.HttpGet("id")]
        public ActionResult<Members> GetMemberById(int id)
        {
            return members.GetMember(id);
        }
    }
}