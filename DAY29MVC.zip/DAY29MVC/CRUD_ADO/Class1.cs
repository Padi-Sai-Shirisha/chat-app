﻿//using Microsoft.VisualBasic;
//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.SqlClient;
//using System.Reflection;

//namespace CRUD_ADO
//{
//    public class CRUD
//    {
//        public static Boolean chkValidity(string uname, string pass)
//        {
//            try
//            {
//                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True");
//                con.Open();
//                SqlCommand cmd = new SqlCommand("Select * from loginTbl", con);
//                cmd.CommandType = CommandType.Text;
//                SqlDataReader rdr = cmd.ExecuteReader();
//                while (rdr.Read())
//                {
//                    if (rdr.GetString("uname").Equals(uname) && rdr.GetString("passwd").Equals(pass))
//                        return true;
//                }

//            }
//            catch (Exception e) { return false; }
//            return false;
//        }

//        public static Boolean Insert(string name, string uname, string pass)
//        {
//            try
//            {
//                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True");
//                con.Open();

//                string insertQuery = $"INSERT INTO LoginTbl VALUES ('{name}','{uname}', '{pass}')";

//                SqlCommand cmd = new SqlCommand(insertQuery, con);

//                cmd.CommandType = CommandType.Text;
//                int count = cmd.ExecuteNonQuery();

//                return count > 0;
//            }
//            catch (Exception e) { return false; }

//        }
//        public static Boolean updatePass(string name, string oldpass, string newpass, string conpass)
//        {
//            try
//            {
//                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True");
//                con.Open();

//                string insertQuery = $"select name from LoginTbl WHERE name = '{name}'";

//                SqlCommand cmd1 = new SqlCommand(insertQuery, con);

//                cmd1.CommandType = CommandType.Text;
//                int count1 = cmd1.ExecuteNonQuery();
//                if(count1 == 0)
//                {
//                    return false;
//                }
//                else
//                {
//                    string insertQuery1 = $"select name, passwd from LoginTbl WHERE name = '{name}' and passwd = '{oldpass}'";
//                    SqlCommand cmd2 = new SqlCommand(insertQuery, con);

//                    cmd2.CommandType = CommandType.Text;
//                    int count2 = cmd2.ExecuteNonQuery();

//                    if(count2 == 0)
//                    {
//                        return false;
//                    }
//                    else
//                    {
//                        if (conpass == newpass)
//                        {
//                            string insertQuery2 = $"UPDATE LoginTbl SET passwd = '{newpass}' WHERE name = '{name}' and passwd = '{oldpass}'";
//                            // string insertQuery = $"UPDATE LoginTbl SET passwd = '{newpass}' WHERE name = '{name}' AND passwd = (SELECT passwd FROM LoginTbl WHERE name = '{name}' and passwd = {oldpass})";


//                            SqlCommand cmd = new SqlCommand(insertQuery2, con);

//                            cmd.CommandType = CommandType.Text;
//                            int count = cmd.ExecuteNonQuery();

//                            return count > 0;
//                        }

//                    }
//                }



//               return false;
//            }
//            catch (Exception e) { return false; }

//        }

//        public static Boolean delete(string name, string uname, string passwd)
//        {
//            try
//            {
//                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True");
//                con.Open();
//                string insertQuery = $"Delete from LoginTbl WHERE name = '{name}' and passwd = '{passwd}' and uname = '{uname}'";

//                SqlCommand cmd = new SqlCommand(insertQuery, con);

//                cmd.CommandType = CommandType.Text;
//                int count = cmd.ExecuteNonQuery();

//                return count > 0;
//            }
//            catch (Exception e) { return false; }

//        }

//    }
//}

////SqlCommand cmd = new SqlCommand("Delete from t where i=2 and j=4", con);
////cmd.CommandType = CommandType.Text;
////int recDel = cmd.ExecuteNonQuery();
///

using System;
using System.Data;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace CRUD_ADO
{
    public class CRUD
    {
        public static Boolean Authentication(string uname)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True");
                con.Open();
                ///Select : Read R of CRUD
                SqlCommand cmd = new SqlCommand($"Select * from LoginTbl", con);

                cmd.CommandType = CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
              
                while (rdr.Read())
                {
                    if(rdr.GetString(1) == "admin")
                    {
                        return true;
                    }
                    return false;
                }


                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return false;
            }
        }

        public static Boolean DeletePage(string name, string uname, string passwd)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True");
                con.Open();
                //////Delete: D of CRUD

                SqlCommand cmd = new SqlCommand("Delete from LoginTbl where name=@name AND uname=@uname AND passwd=@passwd", con);

                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@uname", uname);
                cmd.Parameters.AddWithValue("@passwd", passwd);
                cmd.CommandType = CommandType.Text;
                int rt = cmd.ExecuteNonQuery();
                if (rt > 0)
                {
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return false;
            }
        }
    }
}