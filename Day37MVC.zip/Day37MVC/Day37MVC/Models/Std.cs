﻿namespace Day37MVC.Models
{
    public class Std
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}