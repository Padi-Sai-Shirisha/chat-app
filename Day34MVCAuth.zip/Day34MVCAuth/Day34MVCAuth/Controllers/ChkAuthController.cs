﻿using Day34MVCAuth.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Day34MVCAuth.Controllers
{
    public class ChkAuthController : Controller
    {
        static StudentList std = new StudentList();
        // GET: CheckAuth
        public ContentResult Index()
        {
            return Content("Hello, You are Guest.");
        }

		public IActionResult search(int id)
		{
            std.getStd(id);
			return View(std.getStd(id));
		}

		public IActionResult List()
        {
          
            return View(std.ListStd());
        }

        // GET: CheckAuth/AuthorisedOnly  
        [Authorize]
        public ContentResult AuthorisedOnly()
        {
            return Content("You are registered user.");
        }
        [Authorize]
        public IActionResult Welcome()
        {
            return View();
        }

		[Authorize]
        [HttpGet]
		public IActionResult AddStd()
		{
			return View();
		}
        [Authorize]
        [HttpPost]
		public IActionResult AddStd(string name, int id)
		{
			return View();
		}
       
	}
}
