﻿using System.Xml.Linq;

namespace Day34MVCAuth.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Student(string name, int id)
        {
            
            Name = name;
            Id = id;
        }

        public Student() { }

        public override string ToString()
        {
            return "\nEmp: " + Name + " with id: " + Id;
        }
    }
}
