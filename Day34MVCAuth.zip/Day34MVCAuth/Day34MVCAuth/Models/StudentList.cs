﻿namespace Day34MVCAuth.Models
{
    public class StudentList
    {
        public List<Student> emps = new List<Student>();
        public StudentList(List<Student> emps) { this.emps = emps; }
        public StudentList(Student emp) { this.emps.Add(emp); }
        public StudentList()
        {
            this.AddStd(new Student("abc", 101));
            this.AddStd(new Student("xyz", 102));
            this.AddStd(new Student("abcxyz", 103));
        }
        public void AddStd(Student emp) { this.emps.Add(emp); }

        public List<Student> ListStd()
        {
            return emps.ToList();
        }

        public Student getStd(int id)
        {
            Student e = new Student("default", 100);
            foreach (Student ee in emps)
            {
                if (ee.Id.Equals(id))
                {
                    e = ee;
                }
            }

            Student e2 = emps.Find(ee => ee.Id.Equals(id));
            return e;
        }
    }
}
