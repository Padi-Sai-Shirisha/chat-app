﻿using Microsoft.AspNetCore.Mvc;

namespace HttpPandG.Controllers
{
    public class ActController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [ActionName("Index1")]
        public IActionResult Page1()
        {
            return View();
        }
        [HttpGet]
        public IActionResult WelcomePage()
        {
            return View();
        }

        [HttpPost]
        public IActionResult WelcomePage(string emp)
        {
            @ViewData["ans"] = emp;
            return View();
        }
    }
}
