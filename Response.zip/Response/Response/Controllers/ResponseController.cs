﻿using Microsoft.AspNetCore.Mvc;

namespace Response.Controllers
{
    public class ResponseController : Controller
    {
            [ResponseCache(Duration = 10)]
            public ActionResult Index()
            {
                return View();
            }
    }
}
