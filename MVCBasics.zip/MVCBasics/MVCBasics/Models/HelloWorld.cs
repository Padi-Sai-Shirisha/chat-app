﻿using System.Net.Cache;
using System.Reflection.Metadata.Ecma335;

namespace MVCBasics.Models
{
    public class HelloWorld
    {
        private int age;
        public string hello()
        {
            return "Hello World"; 
        }

        public string validate(int age)
        {
            if (age > 150 || age < 0)
                return "ghost !!";
            else if (age > 60)
                return "Retire please !!";
            else if (age < 18)
                return "Go kid play!!";
            else return "welcome";
        }
    }
}
