﻿using System.Collections.Generic;
using System;

namespace MVCBasics.Models
{
    public class Employees
    {
        public List<Employee> empList = new List<Employee>();
        public List<Employee> empage = new List<Employee>();


        public Employees()
        {
            this.empList.Add(new Employee("abc", 101, 23));
            this.empList.Add(new Employee("xyz", 102, 45));
            this.empList.Add(new Employee("rose", 103, 56));
            this.empList.Add(new Employee("john", 103, 35));
            this.empList.Add(new Employee("ram", 103, 27));
        }
        public void AddEmp(string name, int id, int age) 
        { 
            empList.Add(new Employee(name, id, age)); 
        }
        public List<Employee> returnList()
        {
            return empList;
        }
        public List<Employee> returnAge()
        {
            return empage;
        }

        public Employee SearchID(int id)
        {
            foreach (Employee emp in empList)
            {
                if(emp.id  == id) return emp;
            }
            return null;
        }
        public Employee SearchName(string name)
        {
            foreach (Employee emp in empList)
            {
                if (emp.name == name) return emp;
            }
            return null;
        }
        public Employee SearchAge(int age)
        {
            foreach (Employee emp in empList)
            {
                if (emp.age == age) return emp;
            }
            return null;
        }

        public List<Employee> SearchAgeRange(int minage, int maxage)
        {
            foreach (Employee emp in empList)
            {
                if (emp.age >= minage && emp.age <= maxage) 
                    empage.Add(emp);
            }
            return empage;
        }
    }
}
