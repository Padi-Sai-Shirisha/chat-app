﻿namespace MVCBasics.Models
{
    public class Employee
    {
        public string name { get; set; }
        public int id { get; set; }
        public int age { get; set; }
        public Employee() { }
        public Employee(string name, int id, int age)
        {
            this.name = name;
            this.id = id;
            this.age = age;
        }

        public override string ToString()
        {
            return "\nEmp: " + name + " with id: " + id + " of age: " + age;
        }
    }
}
