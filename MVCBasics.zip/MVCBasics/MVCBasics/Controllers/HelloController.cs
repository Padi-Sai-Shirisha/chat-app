﻿using Microsoft.AspNetCore.Mvc;
using MVCBasics.Models;

namespace MVCBasics.Controllers
{
    public class HelloController : Controller
    {
        HelloWorld hlo = new HelloWorld();
        public IActionResult Index()
        {
           
            ViewData["var"] = hlo.hello();
            return View();
        }
        public IActionResult Sayhi(string name)
        {
            ViewBag.name = name;
            return View();
        }
        public IActionResult hr(string name, int age)
        {
            ViewData["emp"] = hlo.validate(age);

            return View();
        }
    }
}
