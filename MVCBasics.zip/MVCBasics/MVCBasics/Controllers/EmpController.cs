﻿using Microsoft.AspNetCore.Mvc;
using MVCBasics.Models;
using System.Collections.Generic;

namespace MVCBasics.Controllers
{
    public class EmpController : Controller
    {
        static Employees emps = new Employees();
        public List<Employee> empage = new List<Employee>();
        public IActionResult Index()
        {
            return View();
        }
        public JsonResult Show()
        {
            return Json(emps.returnList());
        }
        public IActionResult AddEmp(string name, int id, int age)
        {
            emps.AddEmp(name, id, age);
            return View();
        }
        public IActionResult SearchID(int id)
        {
            if (emps.SearchID(id) is null)
                ViewData["id"] = "Employee not found by id";
            else
                ViewData["id"] = emps.SearchID(id);
            return View();
        }
        public IActionResult SearchName(string name)
        {
            if (emps.SearchName(name) is null)
                ViewData["name"] = "Employee not found by name";
            else
                ViewData["name"] = emps.SearchName(name);
            return View();
        }
        public IActionResult SearchAge(int age)
        {
            if (emps.SearchAge(age) is null)
                ViewData["age"] = "Employee not found by age";
            else
                ViewData["age"] = emps.SearchAge(age);
            return View();
        }
        public IActionResult ByRange(int minage, int maxage)
        {
            empage = emps.SearchAgeRange(minage, maxage);
            string empsage = "";

            foreach (var item in empage)
            {
                empsage += item + "\n";

                ViewData["empsage"] = empsage;
               
            }
            return View();


        }
    }
}
