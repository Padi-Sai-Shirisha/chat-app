﻿using Microsoft.AspNetCore.Mvc;

namespace Day36MVCAPI.Controllers
{
    public class ConsumerStdAPIController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
