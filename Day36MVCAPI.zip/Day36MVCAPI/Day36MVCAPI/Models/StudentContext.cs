﻿namespace Day36MVCAPI.Models
{
    public class StudentContext
    {
    }
}
