﻿using Microsoft.AspNetCore.Mvc;

namespace Day34MVC.Controllers
{
    public class HiddenFFController : Controller
    {
        public IActionResult Index()
        {
            //ViewData["Guest"] = "";
            return View();
        }
        public IActionResult Welcome1(string uname)
        {
            ViewData["uname"] = uname;
            return View();
        }
        [HttpPost]
        public IActionResult Welcome2(string uname)
        {
            ViewData["uname"] = uname;
            return View();
        }
    }
}
