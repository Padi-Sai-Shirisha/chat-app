﻿using System;
using System.Collections.Generic;
using System.Text;
/*
using System;
class Pa
{
    public virtual void fn()
    {
        Console.WriteLine("fn in Pa");
    }
}
class Child : Pa
{
    public override void fn()
    {
        Console.WriteLine("fn in Child");
    }
}
class Program
{

    static void Main()
    {
        Pa p2 = new Pa();
        p2.fn();
        Pa p = new Child();
        p.fn();
        Child ch = new Child();
        ch.fn();

    }
}
*/
using System;

abstract class HR
{
    public abstract void leave();
}
interface IEmp
{
    void appraisal();
}
class Emp : HR, IEmp
{
    public void appraisal()
    {
        Console.WriteLine("The Interface Method is Implemented");
    }

    public override void leave()
    {
        Console.WriteLine("The Abstract class Method is Implemented/Extended");
    }
}

class Program
{

    static void Main()
    {
        IEmp e1 = new Emp();
        e1.appraisal();
        HR e2 = new Emp();
        e2.leave();
        Emp e3 = new Emp();
        e3.appraisal();
        e3.leave();

    }
}














/*

using System;


class Program
{
    public void fn(in int x, out int sq, out int cu, out int sa)
    {
        //x = x + 10;
        sq = x * x;
        cu = x * x * x;
        sa = x + x;

    }
    static void Main()
    {
        int x = 12;
        int sq, cu, sa;
        Program p = new Program();
        p.fn(in x, out sq, out cu, out sa);
        Console.WriteLine("x = " + x + " \nsquare = " + sq + "\nCube = " + cu + "\nSelf addition = " + sa);


    }
}

*/







