﻿using Microsoft.AspNetCore.Mvc;

namespace exercise.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Welcome(string name, string name1)
        {
            //ViewData["EmpName"] = "Monica";

            ViewData["FName"] = name;
            ViewData["LName"] = name1;


            return View();
        }
        public IActionResult Form()
        {

            return View();
        }

    }
}
