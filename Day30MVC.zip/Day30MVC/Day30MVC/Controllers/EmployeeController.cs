﻿using Day30MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace Day30MVC.Controllers
{
    public class EmployeeController : Controller
    {
        static EmployeeList emps = new EmployeeList();
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult WelcomeEmp(string name)
        {
            TempData["Emp"] = emps.getEmp(name);
            return View();
        }
        public IActionResult WelcomeEmp2(string name)
        {
            TempData["EmpName"] = name;
            return View();
        }
        public IActionResult ListEmp()
        {
            return View(emps.emps);
        }

        public JsonResult ListEmp2()
        {
            return Json(emps.emps);
        }

        public IActionResult AddEmpD()
        {
            return View();
        }
        public IActionResult Add(string name, int id)
        {
            Employee e = new Employee(name, id);
            emps.AddEmp(e);
            return RedirectToAction("ListEmp2");
        }

        public IActionResult UpdateD()
        {
            return View();
        }

        public IActionResult Update(string name, int id) 
        {
            foreach (Employee ee in emps.emps)
            {
                if (ee.id.Equals(id))
                {
                    ee.name = name;
                }
            }
            return RedirectToAction("ListEmp2");
        }

    }
}