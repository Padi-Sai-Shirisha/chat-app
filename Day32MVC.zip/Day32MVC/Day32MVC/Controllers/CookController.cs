﻿using Microsoft.AspNetCore.Mvc;

namespace Day32MVC.Controllers
{
    public class CookController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult AddCooky(string cooky)
        {
            HttpContext.Response.Cookies.Append("clientCookie", cooky);
            return View();
        }
        public IActionResult ViewCooky(string cooky)
        {
            string myCookie = "";
            if (HttpContext.Request.Cookies.ContainsKey("clientCookie"))
            {
                myCookie = HttpContext.Request.Cookies["clientCookie"];
            }
            ViewData["cooky"] = myCookie;
            return View();
        }
        public IActionResult loggin(string username, string password)
        {
            HttpContext.Response.Cookies.Append("uname", username);
            HttpContext.Response.Cookies.Append("pass", password);
            return View();
        }
        public IActionResult login()
        { 
            return View();
        }
        public IActionResult inbox()
        {
            string uname = "";
            string pass = "";
            if (HttpContext.Request.Cookies.ContainsKey("uname"))
            {
                uname = HttpContext.Request.Cookies["uname"];
            }
            if (HttpContext.Request.Cookies.ContainsKey("pass"))
            {
                pass = HttpContext.Request.Cookies["pass"];
            }
            ViewData["uname"] = uname;
            ViewData["pass"] = pass;
            return View();
        }
      
    }
}
