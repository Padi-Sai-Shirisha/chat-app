﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services.Models;
using System.Collections.Generic;

namespace Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StdController : ControllerBase
    {
            private static StudentContext students = new StudentContext();
            [HttpGet]
            [Route("Stds")]
            [EnableCors("AllowOrigin")]
            public ActionResult<IEnumerable<Student>> GetAllStudents()
            {
                return students.GetAllStudent();
            }
            [HttpGet("{id:int}")]
            [EnableCors("AllowOrigin")]
        public ActionResult<Student> GetStudentById(int id)
            {
                return students.GetStudent(id);
            }

        
    }
}
