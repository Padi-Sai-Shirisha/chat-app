﻿using Microsoft.AspNetCore.Mvc;
using Day35MVC.Models;

namespace Day35MVC.Controllers
{
    [TypeFilter(typeof(MyExceptFilter))]

    public class ExceptHandleController : Controller
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}

        public IActionResult Index() =>
        Content($"- {nameof(ExceptHandleController)}.{nameof(Index)}");

    }
}