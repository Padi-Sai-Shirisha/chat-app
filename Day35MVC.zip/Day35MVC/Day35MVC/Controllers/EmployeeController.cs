﻿using Day35MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using static System.Net.Mime.MediaTypeNames;
using System.Collections.Generic;
using System.Reflection.Emit;
using System.Threading;
using System.Xml.Linq;

namespace Day35MVC.Controllers
{
	public class EmployeeController : Controller
	{
		static EmployeeClass emp = new EmployeeClass();
		public IActionResult Index()
		{
			return View();
		}
		public IActionResult HTMLHelper1()
		{
			return View();
		}
		public IActionResult HTMLHelper2()
		{
			return View();
		}
		[HttpPost]
		public IActionResult HTMLHelper2(EmployeeClass emp1)
		{
			emp = emp1;
			return RedirectToAction("HTMLHelper3");
		}

		public IActionResult HTMLHelper3()
		{
			//Here we have hardcoded the Employee Details. In Realtime you will get the data from any data source
			EmployeeClass employee = new EmployeeClass()
			{
				EmpId = 1,
				Name = "Jayanta Roy",
				Gender = "Male",
				city = city.Dehli,
				skills = skills.WebAPI,
				Address = "Vaishali",
				AgreeTerm = true
			};
			ViewData["EmployeeData"] = emp;
			return View();
		}

	}
}




