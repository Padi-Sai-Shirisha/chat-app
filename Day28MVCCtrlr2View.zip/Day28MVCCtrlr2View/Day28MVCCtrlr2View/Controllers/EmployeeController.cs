﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace Day28MVCCtrlr2View.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public Boolean ValidLogin(string username, string password)
        {
            string connectionString = "Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);

            Console.Write("Enter Username: ");
            string username = Console.ReadLine();

            Console.Write("Enter Password: ");
            string password = Console.ReadLine();

            string query = $"SELECT COUNT(*) FROM Login WHERE uname = '{username}' AND passwd = '{password}'";

            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);

            int count = (int)cmd.ExecuteScalar();

            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            connection.Close();

            Console.ReadLine();

            return true;
        }
        public IActionResult WelcomeEmp()
        {
            //ViewData["EmpName"] = "Monica";
            //ViewBag.EmpName = "Monica";
            TempData["EmpName"] = "Monica";


            return View();
        }
        public IActionResult WelcomeEmp2(string name)
        {
            //ViewData["EmpName"] = name;
            //ViewBag.EmpName = name;
            TempData["EmpName"] = name;

            return View();
        }

        public IActionResult Welcome1(string name)
        {
            if(name == "PWC")
                return RedirectToAction("Welcome2");
            else
                return RedirectToAction("Welcome3"); 
        }
        public IActionResult Welcome2()
        {
            return View();
        }
        public IActionResult Welcome3()
        {
            return View();
        }

    }
}
