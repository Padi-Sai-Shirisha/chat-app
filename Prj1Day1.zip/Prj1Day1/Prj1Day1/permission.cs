﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Prj1Day1
{
     class permission
    {
       public int id;
        public string name; 
        public string description;  
        public string role;
        public string module;
        public addpermission()
        {
            Console.WriteLine("permission added");
            //add permission function details 
        }
        public editpermission()
        { //run function to edit
        }
        public deletepermission()
        {
            //function delete permission 
        }
        public searchpermission()
        {
            //add code to search permissiom
        }

    }
    public class role
    {
        public string name;
        public string description;
        public string role;
        public addrole()
        {
            //code to add
        }
        public editrole()
        {
            //code
        }
        public deleterole()
        {
            //code
        }
        public assignrole()
        {
            //code
        }
    }
    public class user: permission,role
        {
        public int id;
        public string role;
        public string email;
        public DateTime dob;
        public AddingNewEventArgs user()
        {
            //code
        }
        public


}
