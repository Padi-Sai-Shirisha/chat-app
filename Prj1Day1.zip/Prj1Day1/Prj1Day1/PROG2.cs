﻿/*ng System;
using System.Collections.Generic;
using System.Text;

namespace Prj1Day1
{
    internal class PROG2
    {
        static void Main(string[] args)
        {
            int[] arr = new int[6]; 
            for(int i=0;i<6;i++)
            {
                Console.Write("enter element");
                arr[i]=Convert.ToInt32(Console.ReadLine());

            }
            int max = arr[0];
            int min = arr[0];
            foreach(int num in arr)
            {
                if (num > max)
                    max = num;
                if(num< min) min = num; 
            }
            Console.WriteLine("maximum" + max);
            Console.WriteLine("miimum"+min);
            Console.WriteLine("even no");
            foreach (int num in arr)
            {
                if (num % 2 == 0)
                    Console.WriteLine(num);
            }
            Console.WriteLine("square");
            foreach (int num in arr)
            { Console.WriteLine((num * num));
            }
            Console.WriteLine();
        }

    }
}*/
