﻿using LoginEx.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace LoginEx.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            if (HttpContext.Request.Cookies.ContainsKey("pass"))
            {
                var ans1 = HttpContext.Request.Cookies["pass"];
                TempData["pass"] = ans1;
            }
            else
                TempData["pass"] = null;

            if (HttpContext.Request.Cookies.ContainsKey("login"))
            {
                var ans2 = HttpContext.Request.Cookies["login"];
                TempData["login"] = ans2;
            }
            else
                TempData["login"] = null;

            return View();
        }

        //static int i = 0;
        public IActionResult Index1(string login, string pass)
        {

            if (login != null && pass != null)
            {
                HttpContext.Response.Cookies.Append("login", login);
                HttpContext.Response.Cookies.Append("pass", pass);
            }

            if (HttpContext.Request.Cookies.ContainsKey("pass"))
            {
                var ans1 = HttpContext.Request.Cookies["pass"];
                TempData["pass"] = ans1;
            }
            else
                TempData["pass"] = null;

            if (HttpContext.Request.Cookies.ContainsKey("login"))
            {
                var ans2 = HttpContext.Request.Cookies["login"];
                TempData["login"] = ans2;
            }
            else
                TempData["login"] = null;

            //if (i == 0)
            //{
            //    i = 1;
            //    return RedirectToAction("Index1");
            //}
            //i = 0;

            return RedirectToAction("inbox");
        }
    

        public IActionResult inbox()
        {
            if (HttpContext.Request.Cookies.ContainsKey("pass"))
            {
                var ans1 = HttpContext.Request.Cookies["pass"];
                TempData["pass"] = ans1;
            }
            else
                TempData["pass"] = null;

            if (HttpContext.Request.Cookies.ContainsKey("login"))
            {
                var ans2 = HttpContext.Request.Cookies["login"];
                TempData["login"] = ans2;
            }
            else
                TempData["login"] = null;
            if (TempData["login"] is null || TempData["pass"] is null)
                return RedirectToAction("Empty");
            else
                return RedirectToAction("Full");
            
        }
        public IActionResult Empty()
        {
            return View();
        }
        public IActionResult Full()
        {
            return View();
        }
        public IActionResult draft()
        {
            return View();
        }
        public IActionResult sent()
        {
            return View();
        }
        public IActionResult compose()
        {
            return View();
        }
        public IActionResult log()
        {
          
            HttpContext.Response.Cookies.Delete("login");
           
            HttpContext.Response.Cookies.Delete("pass");

            TempData["login"] = null;
            TempData["pass"] = null;

           

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
