﻿using Microsoft.AspNetCore.Mvc;

namespace Day27MySite.Views.Employee
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
