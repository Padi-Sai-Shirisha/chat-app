﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlExercise
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);

            Console.Write("Enter Username: ");
            string username = Console.ReadLine();

            Console.Write("Enter Password: ");
            string password = Console.ReadLine();

            string query = $"SELECT COUNT(*) FROM Login WHERE uname = '{username}' AND passwd = '{password}'";

            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);

            int count = (int)cmd.ExecuteScalar();

            if (count > 0)
            {
                Console.WriteLine("Login successful"+ count);
            }
            else
            {
                Console.WriteLine("Login NOT successful");
            }
            connection.Close();

            Console.ReadLine();
            
          }
    }
}

  
