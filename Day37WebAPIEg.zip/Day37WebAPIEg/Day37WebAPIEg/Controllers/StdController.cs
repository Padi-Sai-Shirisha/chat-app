﻿using Day37WebAPIEg.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Day37WebAPIEg.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StdController : ControllerBase
    {
        static StdList stds = new StdList();
        [HttpGet]
        public ActionResult<IEnumerable<Std>> getAll()
        {
            return stds.getAllStds();
        }

        [HttpGet("{id}")]
        public ActionResult<Std> getStd(int id)
        {
            return stds.getStd(id);
        }

    }
}
