﻿using System.Collections.Generic;
using System.Linq;

namespace Day37WebAPIEg.Models
{
    public class StdList
    {
        List<Std> stds = new List<Std>()
        {
            new Std{id=101,name="aaa"},
            new Std{id=102,name="bbb"},
            new Std{id=103,name="ccc"}
        };
        public List<Std> getAllStds()
        {
            return stds;
        }
        public Std getStd(int id)
        {
            return stds.FirstOrDefault(st => st.id == id);
        }
    }
}
