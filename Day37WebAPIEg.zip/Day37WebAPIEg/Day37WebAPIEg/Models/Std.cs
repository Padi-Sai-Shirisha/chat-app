﻿namespace Day37WebAPIEg.Models
{
    public class Std
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
