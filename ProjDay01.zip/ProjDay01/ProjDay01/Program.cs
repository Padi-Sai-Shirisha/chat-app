﻿using System;
using System.Reflection.Metadata.Ecma335;
using System.Xml;
/*
namespace ProjDay01
{
    interface Operation
    {
        int op(int o1,int o2);
    }
    class Mathoperation
    {
        Operation o;
        int o1;
        int o2;

        public Mathoperation(int o1, int o2, Operation o)
        {
            this.o = o;
            this.o1 = o1;
            this.o2 = o2;
        }
        public void operate()
        {
            Console.WriteLine(o.op(o1, o2));
        }
    }
    class Sum1 : Operation
    {
        public int op(int o1, int o2)
        {
            output();
            return (o1+o2);
        }


        static void output()
        {
            Console.WriteLine("THE SUM IS");
        }
    }
    class Minus1 : Operation
    {
        public int op(int o1, int o2)
        {
            output();
            return (o1-o2);
        }


        static void output()
        {
            Console.WriteLine("THE Substract IS");
        }
    }
    class multiply1 : Operation
    {
        public int op(int o1, int o2)
        {
            output();
            return( o1*o2);
        }


        static void output()
        {
            Console.WriteLine("THE product IS");
        }
    }
    class divide1 : Operation
    {
        public int op(int o1, int o2)
        {
            output();
            return (o1/ o2);
        }


        static void output()
        {
            Console.WriteLine("THE divide IS");
        }
    }
    class AbsModel
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("enter 2 nos");
            int x = Convert.ToInt32(Console.ReadLine());
            int y = Convert.ToInt32(Console.ReadLine());
            Mathoperation oper = new Mathoperation(x, y, new Sum1());
            oper.operate();
            Mathoperation oper1 = new Mathoperation(x, y, new Minus1());
            oper1.operate();
            Mathoperation oper2 = new Mathoperation(x, y, new multiply1());
            oper2.operate();
            Mathoperation oper3 = new Mathoperation(x, y, new divide1());
            oper3.operate();
        }
    }
}

class Program
{

    static void Main()
    {
        int[] x = new int[5];  //x[0] to x[4]
        int d = 2;
        try
        {
            try
            {
                Console.WriteLine("Enter a number: numerator : ");
                x[5] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter another number: denominator : ");
                d = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("The square of the number enetered is : " + (d * d));
                int y = x[5] / d;
                Console.WriteLine("Div Result: " + y);

            }
            catch (FormatException e)
            {
                Console.WriteLine("This is a " + e.Message + " exception!");
                int p = d / 0;

            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("This is a " + e.Message + " exception!");
            }
            catch (Exception e)
            {
                Console.WriteLine("This is a " + e.Message + " exception!");
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Outer Catch: This is a " + e.Message + " exception!");
        }

    }

}




*/