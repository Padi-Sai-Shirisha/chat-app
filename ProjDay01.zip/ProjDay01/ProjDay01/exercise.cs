﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
/*
namespace ProjDay01
{
    interface ImyIterator
    {
        int next();
        void begin();
        Boolean hasNext();

    }
    public class myCollection
    {
        private int[] arr = new int[10000];
        private int tos = -1;
        int nav = -1;
        public void add(int i)
        {
            tos = tos + 1;
            arr[tos] = i;
        }

        public class Myiterator : ImyIterator
        {
            private myCollection collection;
            public Myiterator(myCollection collection)
            {
                this.collection = collection;
            }
            public int next()
            {
                if (collection.tos != -1 && collection.nav <= collection.tos)
                {
                    int value = collection.arr[collection.nav];
                       collection.nav++;
                    return value;
                }
                return -1;
            }
            public void begin()
            {
                if (collection.tos > 0)
                {
                    collection.nav = 0; 
                }
            }
            public bool hasNext()
            { return collection.nav <= collection.tos;
            }
        }
        public Myiterator Getiterator()
        {
            return new Myiterator(this);
        }
    }

    class Program
    {

        static void Main()
        {
            myCollection c1 = new myCollection();
            c1.add(10);
            c1.add(78);
            c1.add(76);
            c1.add(55);
            c1.add(49);
            ImyIterator it = c1.Getiterator();
            it.begin();
            while(it.hasNext())
            {
                int val = it.next();
                if (val != -1)
                {
                    Console.WriteLine(val);
                }
                else {
                    Console.WriteLine("no");
                     }
            }
        }
    }
}
*/
