﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjDay01
{
    class Mynumber
    {
        private int value;
       //constructor to initialize Mynumber object with a double value
        public Mynumber(int val)
        {
            value = val;
        }
        //overload the modulus operator for Mynumber objects
        public static Mynumber operator %(Mynumber a, Mynumber b)
        {
            return new Mynumber((a.value % b.value));
           
        }
        //overload the division operator for Mynumber objects
        public static Mynumber operator /(Mynumber a , Mynumber b)
        {
            
                return new Mynumber((a.value / b.value));

        }
        //overload the multiplication operator for Mynumber objects
        public static Mynumber operator *(Mynumber a, Mynumber b)
        {
            return new Mynumber((a.value * b.value));

        }
        //override the ToString method to provide string representation of Mynumber object
        public override string ToString()
        {
            return value.ToString();
        }
    }
    class program
    {

        static void Main()

        {
          
                Console.WriteLine("enter 2 nos");
            //create 2 Mynumber objects
                int a = int.Parse(Console.ReadLine());
                int b = Convert.ToInt32(Console.ReadLine());
                Mynumber a1 = new Mynumber(a);

                Mynumber b1 = new Mynumber(b);
            //using overload operator
                Mynumber result = a1 % b1;
                Mynumber result1 = a1 / b1;
               
                Mynumber result2 = a1 * b1;
            Mynumber result3=( b1 % a1)*b1/a1;
            //print the results
            Console.WriteLine(" the modulus result is " + result);

                Console.WriteLine(" the multiplication result is " + result2);
                Console.WriteLine("the division result is " + result1);
            Console.WriteLine("the mixed result is " + result3);

        }
    }

    }
        
    
