﻿using System;
using System.Collections.Generic;
using System.Text;
/*
    public class CDROM
    {
        private string s;
            private bool isValueSet = false;
        
        public string S
        {
            get { return s; }

            set
            {
                if (!isValueSet)
                {
                    s = value;
                }
                else
                {
                    throw new InvalidOperationException("property can be read once");
                }
            }
        }
    }
    class Program
    {
        static void Main()
        {
            CDROM cdrom = new CDROM();
            cdrom.S = "this is write once";
            Console.WriteLine(cdrom.S);
            
        }

    }

*/