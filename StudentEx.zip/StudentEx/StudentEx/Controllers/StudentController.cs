﻿using Microsoft.AspNetCore.Mvc;
using StudentEx.Models;
using System.Data;

namespace StudentEx.Controllers
{
    public class StudentController : Controller
    {
        static StudentList stds = new StudentList();
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult searchByCrt()
        {
            return View();
        }
       
        public IActionResult Byname()
        {
            return View();
        }
        public IActionResult name(string name)
        {
            TempData["Std"] = stds.getStdname(name);
            return View();
        }
        public IActionResult Bydate()
        {
            return View();
        }
        public IActionResult date(string date)
        {
            TempData["Std"] = stds.getStddt(date);
            return View();
        }
        public IActionResult Byfees()
        {
            return View();
        }
        public IActionResult fees(int fees)
        {
            TempData["Std"] = stds.getStdfees(fees);
            return View();
        }

        public IActionResult Byyear()
        {
            return View();
        }
        public IActionResult year(int year)
        {
            TempData["Std"] = stds.getStdyr(year);
            return View();
        }
        public IActionResult ByCourse()
        {
            return View();
        }
        public IActionResult course(string course)
        {
            TempData["Std"] = stds.getStdcr(course);
            return View();
        }


        public IActionResult DeleteStd()
        {
            return View();
        }
        public IActionResult delete(int id)
        {
            stds.DeleteStdId(id);
            return RedirectToAction("ListStd");
        }
        public IActionResult SearchID(int id)
        {
            TempData["Std"] = stds.getStd(id);
            return View();
        }
        public IActionResult Search()
        {
            return View();
        }
        public IActionResult ListStd()
        {
            return View(stds.stds);
        }

        public JsonResult ListStd2()
        {
            return Json(stds.stds);
        }

        public IActionResult AddStd()
        {
            return View();
        }
        public IActionResult Add(string name, int id, string course, int years, string date, int fees)
        {
            Student e = new Student(name, id, course, years, date, fees);
            stds.AddStd(e);
            return RedirectToAction("ListStd2");
        }

        public IActionResult UpdateStd()
        {
            return View();
        }

    

        public IActionResult updateName(string name, int id)
        {
            foreach (Student ss in stds.stds)
            {
                if (ss.id.Equals(id))
                {
                    ss.name = name;
                }
            }
            return RedirectToAction("ListStd");
        }

        public IActionResult updateCourse(string course, int id)
        {
            foreach (Student ss in stds.stds)
            {
                if (ss.id.Equals(id))
                {
                    ss.course = course;
                }
            }
            return RedirectToAction("ListStd");
        }
        public IActionResult updateYears(int year, int id)
        {
            foreach (Student ss in stds.stds)
            {
                if (ss.id.Equals(id))
                {
                    ss.years = year;
                }
            }
            return RedirectToAction("ListStd");
        }
        public IActionResult updateDate(string date, int id)
        {
            foreach (Student ss in stds.stds)
            {
                if (ss.id.Equals(id))
                {
                    ss.date = date;
                }
            }
            return RedirectToAction("ListStd");
        }
        public IActionResult updatefees(int fees, int id)
        {
            foreach (Student ss in stds.stds)
            {
                if (ss.id.Equals(id))
                {
                    ss.fees = fees;
                }
            }
            return RedirectToAction("ListStd");
        }
    }
}

