﻿using System.Collections.Generic;
using System;
using StudentEx.Models;

namespace StudentEx.Models
{
    public class StudentList
    {
        public List<Student> stds = new List<Student>();
        public StudentList(List<Student> stds) { this.stds = stds; }
        public StudentList(Student std) { this.stds.Add(std); }
        public StudentList()
        {
            this.AddStd(new Student("ab", 101, "cs", 4, "12-06-2023", 1000));
            this.AddStd(new Student("bc", 102, "ms", 5, "02-07-2023", 2000));
            this.AddStd(new Student("cd", 103, "ee", 4, "22-06-2023", 3000));
        }
        public void AddStd(Student std) { this.stds.Add(std); }

        public void DeleteStdId(int id)
        {
            Student s = new Student("default", 100, "cs", 4, "12-12-2023", 1000);

            foreach (Student ss in stds)
            {
                if (ss.id.Equals(id))
                {
                    s = ss;
                }
            }
            stds.Remove(s);
        }


        public void DispStd()
        {
            foreach (Student e in stds)
            {
                Console.WriteLine(e);
            }
        }
        public Student getStd(int id)
        {
            Student s = new Student("default", 100, "cs", 4, "12-12-2023", 1000);

            foreach (Student ss in stds)
            {
                if (ss.id.Equals(id))
                {
                    s = ss;
                }
            }

            Student s2 = stds.Find(ss => ss.id.Equals(id));
            return s2 ?? s;
        }
        public Student getStdname(string name)
        {
            Student s = new Student("default", 100, "cs", 4, "12-12-2023", 1000);

            foreach (Student ss in stds)
            {
                if (ss.name.Equals(name))
                {
                    s = ss;
                }
            }

            Student s2 = stds.Find(ss => ss.name.Equals(name));
            return s2 ?? s;
        }
        public Student getStdcr(string course)
        {
            Student s = new Student("default", 100, "cs", 4, "12-12-2023", 1000);

            foreach (Student ss in stds)
            {
                if (ss.course.Equals(course))
                {
                    s = ss;
                }
            }

            Student s2 = stds.Find(ss => ss.course.Equals(course));
            return s2 ?? s;
        }
        public Student getStdyr(int years)
        {
            Student s = new Student("default", 100, "cs", 4, "12-12-2023", 1000);

            foreach (Student ss in stds)
            {
                if (ss.years.Equals(years))
                {
                    s = ss;
                }
            }

            Student s2 = stds.Find(ss => ss.years.Equals(years));
            return s2 ?? s;
        }
        public Student getStddt(string date)
        {
            Student s = new Student("default", 100, "cs", 4, "12-12-2023", 1000);

            foreach (Student ss in stds)
            {
                if (ss.date.Equals(date))
                {
                    s = ss;
                }
            }

            Student s2 = stds.Find(ss => ss.date.Equals(date));
            return s2 ?? s;
        }
        public Student getStdfees(int fees)
        {
            Student s = new Student("default", 100, "cs", 4, "12-12-2023", 1000);

            foreach (Student ss in stds)
            {
                if (ss.fees.Equals(fees))
                {
                    s = ss;
                }
            }

            Student s2 = stds.Find(ss => ss.fees.Equals(fees));
            return s2 ?? s;
        }

    }
}

