﻿using Day36WebAPI.Model;
using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Cryptography;
using System.Xml.Linq;

namespace Day36WebAPI.Model
{
    public class EmpList
    {
        public List<Employee> emps = new List<Employee>();
        public EmpList(List<Employee> emps) { this.emps = emps; }
        public EmpList(Employee emp) { this.emps.Add(emp); }
        public EmpList()     {
            this.emps.Add(new Employee { eid = 1, ename = "Kirtesh", esal = 1000, eaddress = "Vadodara", ephone = 00000000000 });
            this.emps.Add(new Employee { eid = 2, ename = "Nitya", esal = 2000, eaddress = "Vadodara", ephone = 00000000000 });
            this.emps.Add(new Employee { eid = 3, ename = "Dilip", esal = 30000, eaddress = "Vadodara", ephone = 00000000000 });
            this.emps.Add(new Employee { eid = 4, ename = "Atul", esal = 4000, eaddress = "Vadodara", ephone = 00000000000 });
            this.emps.Add(new Employee { eid = 5, ename = "Swati", esal = 5000, eaddress = "Vadodara", ephone = 00000000000 });
        }

        public void AddEmp(int id, string name, int sal, string address, int phn)
        {
            Employee newEmployee = new Employee
            {
                eid = id,
                ename = name,
                esal = sal,
                eaddress = address,
                ephone = phn
            };

            this.emps.Add(newEmployee);
        }

        public List<Employee> GetEmps()
        {
            return this.emps;
        }
        public string DelEmp(int id)
        {
            foreach (Employee e in emps)
            {
                if(e.eid == id)
                {
                    emps.Remove(e);
                    return "deleted";
                }
            }
            return "";
        }
        public Employee GetEmp(int id)
        {
            foreach (Employee ee in emps)
            {
                if (ee.eid.Equals(id))
                {
                    return ee;
                }
            }

           
            return null;
        }
    }
}

//Add 5 emps
//GetEmps
//        GetEmp(eid)
//        AddEmp(eid, ename, esal, eaddress, ephone)
//        DelEmp(eid)

