﻿using System.Security.Cryptography;
using System.Xml.Linq;

namespace Day36WebAPI.Model
{
    public class Employee
    {
        public int eid { get; set; }
        public string ename { get; set; }
        public int esal { get; set; }
        public string eaddress { get; set; }
        public int ephone { get; set; }


        public Employee() { }

        public Employee(int eid, string ename, int esal, string eaddress, int ephone)
        {
            this.eid = eid;
            this.ename = ename;
            this.esal = esal;
            this.eaddress = eaddress;
            this.ephone = ephone;
        }   
    }

   

}
