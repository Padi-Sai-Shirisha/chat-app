﻿using System.Runtime.Serialization;

namespace Day36WebAPI.Models
{
    [DataContract]
    public class Emp
    {
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string Description { get; set; }
    }

}
