﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using Day36WebAPI.Models;
using System.Runtime.Serialization.Json;
using System.Text;
using System;

namespace Day36WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpController : ControllerBase
    {

        [HttpGet]
        public ActionResult<string> Get()
        {
            Emp empObj = new Emp()
            {
                Name = "Jay",
                Description = "IT"
            };

            DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(Emp));
            MemoryStream msObj = new MemoryStream();
            js.WriteObject(msObj, empObj);
            msObj.Position = 0;
            StreamReader sr = new StreamReader(msObj);

            // "{\"Description\":\"IT\",\"Name\":\"Jay\"}"
            string json = sr.ReadToEnd();

            sr.Close();
            msObj.Close();
            return json;
        }
        [HttpGet("id")]
        public ActionResult<Emp> Geting(int id)
        {
            string json = "{\"Description\":\"IT\",\"Name\":\"Jay\"}";

            using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(json)))
            {
                // Deserialization from JSON
                DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(Emp));
                Emp emp = (Emp)deserializer.ReadObject(ms);
                //Console.Write("Name: " + emp.Name); // Name: Jay
                //Console.Write("Description: " + emp.Description); // Description: IT
                return emp;
            }
            //return null;

        }
    }
}