﻿using Day36WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;


namespace Day36WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private static EmpList empList = new EmpList();

        [Microsoft.AspNetCore.Mvc.HttpGet]
        public ActionResult<List<Employee>> GetEmps()
        {
           
            return empList.GetEmps(); 
        }


        [Microsoft.AspNetCore.Mvc.HttpGet("id")]
        public ActionResult<Employee> GetEmp(int id)
        {

            return empList.GetEmp(id);
        }

        [Microsoft.AspNetCore.Mvc.HttpPost]
        public ActionResult<string> AddEmp(int id, string name, int sal, string address, int phn)
        {
            empList.AddEmp(id,name,sal,address,phn);
            return "Employee added successfully.";
        }

        [Microsoft.AspNetCore.Mvc.HttpDelete("id")]
        public ActionResult<string> DeleteEmp(int id)
        {
            empList.DelEmp(id);
            return "Deleted";
        }
    }
}
