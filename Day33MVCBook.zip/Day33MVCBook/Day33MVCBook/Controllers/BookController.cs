﻿using Day33MVCBook.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace Day33MVCBook.Controllers
{
    public class BookController : Controller
    {
        static BookList books = new BookList();
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult BooksList()
        {
            return View(books.ViewAllBooks());
        }
       
        public IActionResult Cart()
        {
            int sum = 0;
            foreach (var book in books.viewCart())
            {
                sum += book.Price;
            }
            ViewData["sum"] = sum;
            ViewData["InCookie"] = "";
            if (HttpContext.Request.Cookies.ContainsKey("CartBooks"))
                ViewData["InCookie"] += HttpContext.Request.Cookies["CartBooks"];
            return View(books.viewCart());
        }
        public IActionResult AddToCart(int iSBN_No)
        {
            books.AddToCart(books.getBook(iSBN_No));

            HttpContext.Response.Cookies.Append("CartBooks", books.booksCart(), new CookieOptions { MaxAge = TimeSpan.FromDays(1) });

            return RedirectToAction("Index");
        }
    }
}
