﻿using Microsoft.AspNetCore.Mvc;

namespace Day33MVCBook.Controllers
{
    public class HiddenFFController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Next(string fullName)
        {
            ViewData["fullName"] = fullName;
            return View();
        }
        public IActionResult Next2(string fullName)
        {
            ViewData["fullName"] = fullName;
            return View();
        }

    }
}
