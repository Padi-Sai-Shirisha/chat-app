﻿using Day33MVCBook.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Xml.Linq;

namespace Day33MVCBook.Controllers
{
    public class QuestionController : Controller
    {
        static QuestionList ques = new QuestionList();
        static List<Question> list = ques.Get3Questions();
        
        static int[] marks = { 0, 0, 0 };
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult getAns(int Qid)
        {
            ViewData["Ques"] = Qid;
            ViewData["ans"] = ques.getAns(Qid);
            return View();
        }
        public IActionResult List()
        {
            return View(list);
        }
        public IActionResult Q1(string name)
        {
            ViewData["name"] = name;
            return View(list[0]);
        }

        public IActionResult Q2(string ans1, string name)
        {
            if (list[0].Ans == ans1)
            {
                marks[0] = 10;
            }
                
            ViewData["name"] = name;
            return View(list[1]);
        }
        public IActionResult Q3(string ans2, string name)
        {
            if (list[1].Ans == ans2)
            {
                marks[1] = 10;
            }
            ViewData["name"] = name;
            return View(list[2]);
        }
        public IActionResult Result(string ans3, string name)
        {
            if (list[2].Ans == ans3)
            {
                marks[2] = 10;
            }
            var marks_total = marks[0] + marks[1] + marks[2];
            ViewData["name"] = name;
            ViewData["marks"] = marks_total;
            return View();
        }
    }
}
