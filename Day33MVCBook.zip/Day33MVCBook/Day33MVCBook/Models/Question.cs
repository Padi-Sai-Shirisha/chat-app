﻿namespace Day33MVCBook.Models
{
    public class Question
    {
        public int QId { get; set; }
        public string Ques { get; set; }
        public string Opt1 { get; set; }
        public string Opt2 { get; set; }
        public string Opt3 { get; set; }
        public string Opt4 { get; set; }
        public string Ans { get; set; }

        public Question() { }
        public Question(int Qid, string ques, string opt1, string opt2, string opt3, string opt4, string ans)
        {
            QId = Qid;
            Ques = ques;
            Opt1 = opt1;
            Opt2 = opt2;
            Opt3 = opt3;
            Opt4 = opt4;
            Ans = ans;
        }

        public override string ToString()
        {
            return "\n ID : " + QId + "    Question : " + Ques;
        }

        // + "\n Option 1 : " + Opt1 + "\n Option 2 : " + Opt2 + "\n Option 3 : " + Opt3 + "\n Option 4 : " + Opt4
    }
}
