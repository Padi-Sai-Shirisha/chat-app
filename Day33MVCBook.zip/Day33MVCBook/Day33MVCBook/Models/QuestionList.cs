﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;

namespace Day33MVCBook.Models
{
    public class QuestionList
    {
        List<Question> Questions = new List<Question>();

        public QuestionList() 
        {
            Questions.Add(new Question(1, "Apple starts with letter ?", "A", "B", "C", "D", "A"));
            Questions.Add(new Question(2, "Ball starts with letter ?", "A", "B", "C", "D", "B"));
            Questions.Add(new Question(3, "Cat starts with letter ?", "A", "B", "C", "D", "C"));
            Questions.Add(new Question(4, "Dog starts with letter ?", "A", "B", "C", "D", "D"));
            Questions.Add(new Question(5, "Egg starts with letter ?", "F", "B", "E", "D", "E"));
            Questions.Add(new Question(6, "Fan starts with letter ?", "F", "B", "E", "D", "F"));
            Questions.Add(new Question(7, "Girl starts with letter ?", "J", "H", "G", "D", "G"));
            Questions.Add(new Question(8, "Hat starts with letter ?", "J", "H", "G", "D", "H"));
            Questions.Add(new Question(9, "Int starts with letter ?", "J", "H", "G", "I", "I"));
            Questions.Add(new Question(10, "JQuery starts with letter ?", "J", "H", "G", "D", "J"));
        }

        public List<Question> Get3Questions() 
        {
            List<Question> list = new List<Question>();
            int[] arr = { 0, 0, 0 };

            Random rnd = new Random();

            int n = rnd.Next(3,10);
            for (int j = n-3; j < n; j++)
            {
                list.Add(Questions[j]);
            }

            //for (int j = 0; j < 3; j++)
            //{
            //    int val = rnd.Next(1, 11);
            //    arr[j] = val;
            //}
            //foreach (int ele in arr)
            //{
            //    foreach (Question q in Questions)
            //    {
            //        if (q.QId == ele)
            //            list.Add(q);

            //    }
            //}
            return list;
        }

        public String getAns(int Qid)
        {
            string s = "";
            foreach (Question q in Questions)
            {
                if(q.QId == Qid)
                    s = q.Ans;
            }
            return s;
        }

    }
}
