﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Day34MVC_EF.Models;

namespace Day34MVC_EF
{
    public class EmployeeEFsController : Controller
    {
        private readonly EmployeeEFContext _context;

        public EmployeeEFsController(EmployeeEFContext context)
        {
            _context = context;
        }

        // GET: EmployeeEFs
        public async Task<IActionResult> Index()
        {
            return View(await _context.EmployeeEFs.ToListAsync());
        }

        // GET: EmployeeEFs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeEF = await _context.EmployeeEFs
                .FirstOrDefaultAsync(m => m.id == id);
            if (employeeEF == null)
            {
                return NotFound();
            }

            return View(employeeEF);
        }

        // GET: EmployeeEFs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: EmployeeEFs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id,name,salary")] EmployeeEF employeeEF)
        {
            if (ModelState.IsValid)
            {
                _context.Add(employeeEF);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(employeeEF);
        }

        // GET: EmployeeEFs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeEF = await _context.EmployeeEFs.FindAsync(id);
            if (employeeEF == null)
            {
                return NotFound();
            }
            return View(employeeEF);
        }

        // POST: EmployeeEFs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,name,salary")] EmployeeEF employeeEF)
        {
            if (id != employeeEF.id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employeeEF);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeEFExists(employeeEF.id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employeeEF);
        }

        // GET: EmployeeEFs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeEF = await _context.EmployeeEFs
                .FirstOrDefaultAsync(m => m.id == id);
            if (employeeEF == null)
            {
                return NotFound();
            }

            return View(employeeEF);
        }

        // POST: EmployeeEFs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employeeEF = await _context.EmployeeEFs.FindAsync(id);
            _context.EmployeeEFs.Remove(employeeEF);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeEFExists(int id)
        {
            return _context.EmployeeEFs.Any(e => e.id == id);
        }
    }
}
