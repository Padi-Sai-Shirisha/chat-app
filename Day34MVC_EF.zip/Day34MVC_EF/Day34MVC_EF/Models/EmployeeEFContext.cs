﻿using Microsoft.EntityFrameworkCore;


namespace Day34MVC_EF.Models
{
	public class EmployeeEFContext : DbContext
	{
		public EmployeeEFContext()
		{
		}
		public EmployeeEFContext(DbContextOptions<EmployeeEFContext> options) : base(options)
		{
		}
		public DbSet<EmployeeEF> EmployeeEFs { get; set; }
	}
}