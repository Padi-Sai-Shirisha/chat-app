﻿using System.ComponentModel.DataAnnotations;

namespace Day34MVC_EF.Models
{
	public class EmployeeEF
	{

		[Key]
		public int id { get; set; }

		[Required(ErrorMessage = "Required Name")]
		public string name { get; set; }
		public int salary { get; set; }

	}
}
