﻿namespace Day37MVCAPI.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public string Name { get; set; }
        public string SurName { get; set; }

        public Student(int studentId, string name, string surname)
        {
            this.StudentId = studentId;
            this.Name = name;
            this.SurName = surname;
        }
        public Student() { }

    }
}