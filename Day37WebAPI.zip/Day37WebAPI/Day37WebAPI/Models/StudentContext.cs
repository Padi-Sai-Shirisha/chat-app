﻿using System.Collections.Generic;
using System.Linq;

namespace Day37MVCAPI.Models
{
    public class StudentContext
    {
        public List<Student> student = new List<Student>        {
            new Student { StudentId=101,Name="Abc",SurName="xyz"},
            new Student { StudentId = 102, Name = "Abc2", SurName = "xyz2" },
            new Student { StudentId = 103, Name = "Abc3", SurName = "xyz3" },
            new Student { StudentId = 104, Name = "Abc4", SurName = "xyz4" }
        };
        public List<Student> GetAllStudent()
        {
            return student;
        }

        public List<Student> AddaStudent(int id, string name, string sname)
        {
            student.Add(new Student(id, name, sname));
            return student;
        }

        public Student UpdateStudent(int id, string name, string surname)
        {
            Student s = new Student();
            foreach(Student ss in student)
            {
                if(ss.StudentId == id)
                {
                    ss.Name = name;
                    ss.SurName = surname;
                    s = ss;
                }
            }
            return s;

        }
        public List<Student> deleteStudent(int id)
        {
            foreach (Student ss in student)
            {
                if (ss.StudentId == id)
                {
                   student.Remove(ss);
                    break;
                }
            }
            return student;

        }
        public Student GetStudent(int id)
        {
            return student.FirstOrDefault(x => x.StudentId == id);
        }
        public StudentContext()
        {
            student.Add(new Student { StudentId = 105, Name = "Abc5", SurName = "xyz5" });
            student.Add(new Student { StudentId = 106, Name = "Abc6", SurName = "xyz6" });
            student.Add(new Student { StudentId = 107, Name = "Abc7", SurName = "xyz7" });
            student.Add(new Student { StudentId = 108, Name = "Abc8", SurName = "xyz8" });
        }
    }
}
