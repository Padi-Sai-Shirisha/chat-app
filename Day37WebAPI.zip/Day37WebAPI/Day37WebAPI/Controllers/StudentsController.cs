﻿using Day37MVCAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Day37MVCAPI.Controllers
{

    [ApiController]
    [Produces("application/json")]
    [Route("api/Students")]
    public class StudentsController : ControllerBase
    {
        private static StudentContext students = new StudentContext();
        [Microsoft.AspNetCore.Mvc.HttpGet]
        public ActionResult<IEnumerable<Student>> GetAllStudents()
        {
            return students.GetAllStudent();
        }
        [HttpGet("{id:int}")]
        //[Route("api/Students/{id}")]
        public ActionResult<Student> GetStudentById(int id)
        {
            return students.GetStudent(id);
        }

        [HttpGet("AddStudent/{id:int}/{name}/{sname}")]
        public ActionResult<IEnumerable<Student>> AddStudent(int id, string name, string sname)
        {
            return students.AddaStudent(id, name, sname);
        }
        [HttpGet("UpdateStudent/{id:int}/{name}/{sname}")]
        public ActionResult<Student> UpdateStudentById(int id, string name, string sname)
        {
            return students.UpdateStudent(id, name, sname);
        }

        [HttpGet("DeleteStudent/{id:int}")]
        public ActionResult<IEnumerable<Student>> DeleteStudentById(int id)
        {
            return students.deleteStudent(id);
        }
    }

}