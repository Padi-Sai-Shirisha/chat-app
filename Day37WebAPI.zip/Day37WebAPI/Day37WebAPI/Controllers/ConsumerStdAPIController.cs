﻿using Day37MVCAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Numerics;
using System.Text;
using System.Xml.Linq;

namespace Day37MVCAPI.Controllers
{
    public class ConsumerStdAPIController : Controller
    {
        //string Baseurl = $"{Request.Scheme}://{Request.Host.Value}/";
        string Baseurl = "https://localhost:44303/";
        public static List<Student> StdInfo = new List<Student>();
        public async Task<IActionResult> Index()
        {
           // List<Student> StdInfo = new List<Student>();
            using (var client = new System.Net.Http.HttpClient())
            {
                //Passing service base url
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //Sending request to find web api REST service resource GetAllStudents using HttpClient
                HttpResponseMessage Res = await client.GetAsync("api/Students");
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var StdResponse = Res.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Student list
                    StdInfo = JsonConvert.DeserializeObject<List<Student>>(StdResponse);
                }
                return View(StdInfo);
            }

        }

        public async Task<IActionResult> GetStd(int id)
        {
            Student StdInfo = new Student();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl); //Passing service base url
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //Sending request to find web api REST service resource GetStudentById using HttpClient
                HttpResponseMessage Res = await client.GetAsync("api/Students/" + id);
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var StdResponse = Res.Content.ReadAsStringAsync().Result;
                    StdInfo = JsonConvert.DeserializeObject<Student>(StdResponse);
                }
                return View(StdInfo);
            }
        }

        public async Task<IActionResult> AddStd(int id, string name, string sname)
        {
           // List<Student> StdInfo = new List<Student>();
            using (var client = new System.Net.Http.HttpClient())
            {
                //Passing service base url
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //Sending request to find web api REST service resource GetAllStudents using HttpClient
                HttpResponseMessage Res = await client.GetAsync($"api/Students/AddStudent/{id}/{name}/{sname}");
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var StdResponse = Res.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Student list
                    StdInfo = JsonConvert.DeserializeObject<List<Student>>(StdResponse);
                    
                }
                return View(StdInfo);
            }
               
        }

        public async Task<IActionResult> DelStd(int id)
        {

           // List<Student> StdInfo = new List<Student>();
            using (var client = new System.Net.Http.HttpClient())
            {
                //Passing service base url
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //Sending request to find web api REST service resource GetAllStudents using HttpClient
                HttpResponseMessage Res = await client.GetAsync($"api/Students/DeleteStudent/{id}");
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var StdResponse = Res.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Student list
                    StdInfo = JsonConvert.DeserializeObject<List<Student>>(StdResponse);
                    
                }
                return View(StdInfo);
            }
        }

        public async Task<IActionResult> UpdateStd(int id, string name, string sname)
        {
            Student StdInfo = new Student();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl); //Passing service base url
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //Sending request to find web api REST service resource GetStudentById using HttpClient
                HttpResponseMessage Res = await client.GetAsync($"api/Students/UpdateStudent/{id}/{name}/{sname}");
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var StdResponse = Res.Content.ReadAsStringAsync().Result;
                    StdInfo = JsonConvert.DeserializeObject<Student>(StdResponse);
                    
                }
                return View(StdInfo);
            }
        }


    }
}

//Complete the above API (StudentsController) for having
//AddaStudent(…), UpdateStudent(..), deleteStudent(..)
//functionality.
//Also update the MVC Controller to work with the CRUD functionality
//(create razor view for the controller).