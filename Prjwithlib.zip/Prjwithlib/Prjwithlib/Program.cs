﻿using System;
using PrjLib;

namespace PrjWithLib
{
    class FarAwayChild : Pa
    {
        public FarAwayChild()
        {
            Console.WriteLine("\nInside FarAwayChild : PrjLib.Pa : in a different client project/domain");
            Google();
            FamilyAC();
            VehIns();
            Console.WriteLine("Exit Constructor of FarAwayChild : PrjLib.Pa : in a different client project/domain");
        }
    }
    class Friend
    {
        public Friend()
        {
            Console.WriteLine("\nInside Friend : in a different client project/domain");
            Pa p = new Pa();
            p.Google();
            Console.WriteLine("Exit Constructor of Friend : in a different client project/domain");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Pa pa = new Pa(10); //all access rights including private
            Child child = new Child(); //all rights except private
            Ma ma = new Ma(); //all rights : public and internal
            FarAwayChild farAwayChild = new FarAwayChild(); // all rights : public, protected
            Friend friend = new Friend(); //all public rights

        }
    }
}




