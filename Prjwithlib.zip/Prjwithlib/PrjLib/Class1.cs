﻿using System;

using System;

namespace PrjLib
{
    public class Pa
    {
        public Pa() { }
        public Pa(int i)
        {
            Console.WriteLine("\nInside Pa itself : in same project/domain");
            Google();
            CreditCard();
            AlmirahGold();
            FamilyAC();
            VehIns();
            Console.WriteLine("Exit Constructor of Pa : in same project/domain");
        }
        public void Google()
        {
            Console.WriteLine("public Google in Pa");
        }
        private void CreditCard()
        {
            Console.WriteLine("private CreditCard in Pa");
        }
        internal void AlmirahGold()
        {
            Console.WriteLine("internal AlmirahGold in Pa");
        }
        protected void FamilyAC()
        {
            Console.WriteLine("protected FamilyAC in Pa");
        }
        protected internal void VehIns()
        {
            Console.WriteLine("protected internal Vehicle Insurance in Pa");
        }
    }
    public class Child : Pa
    {
        public Child()
        {
            Console.WriteLine("\nInside Child : Pa : in same project/domain");
            Google();
            AlmirahGold();
            FamilyAC();
            VehIns();
            Console.WriteLine("Exit Constructor of Child : Pa : in same project/domain");
        }
    }
    public class Ma
    {
        public Ma()
        {
            Console.WriteLine("\nInside Ma : in same project/domain");
            Pa p = new Pa();
            p.Google();
            p.AlmirahGold();
            p.VehIns();
            Console.WriteLine("Exit Constructor of Ma : in same project/domain");
        }
    }
    public class Class1
    {
    }
}










